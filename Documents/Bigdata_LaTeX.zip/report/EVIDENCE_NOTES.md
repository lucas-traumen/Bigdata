# Nguồn hình và số liệu

Ngày biên tập: 2026-10-02. Snapshot nguồn: `lucas-traumen/Bigdata@6343a180f84c46b611fbef73db1e394fb201abe3`.

## Danh mục hình

| File | Nội dung | Cơ sở |
|---|---|---|
| `ch1-rq-map.tex` | Đặc thù IoT → yêu cầu pipeline → năm RQ | Sơ đồ khái niệm, không phải kết quả đo |
| `ch2-time-taxonomy.tex` | Các mốc thời gian của event | Data contract và metadata Kafka/Spark |
| `ch2-validation-levels.tex` | Validation row/metric và khử trùng event | `validation.py`, `stream_app.py`, `pg_sink.py`, `batch.py` |
| `ch2-partition-concurrency.tex` | Kafka partition và slot xử lý Spark | Sơ đồ minh họa tính song song; không khẳng định key được phân bố đều |
| `ch2-mqtt-ack.tex` | Hai vòng PUBACK và ACK thủ công của Bridge | MQTT 3.1.1 và `bridge.py`; trình tự khái niệm |
| `ch3-architecture.tex` | Kiến trúc năm tầng của baseline | `compose.yaml` và các thành phần runtime; vẽ lại hình hiện có |
| `ch3-event-classification.tex` | Phân loại event và xử lý metric | `validation.py`; vẽ lại hình hiện có |
| `ch3-q3-transaction.tex` | Staging và giao dịch PostgreSQL của Q3 | `pg_sink.py`; không biểu diễn giao dịch nguyên tử xuyên Parquet/PostgreSQL |
| `ch4-microbatch.tex` | P50/P95 thời gian xử lý Q1/Q2a/Q2b/Q3 | Số liệu được báo cáo từ run `load15-clean-20261002` |
| `ch4-payload-accounting.tex` | Payload source/Bridge/Bronze so với ngưỡng 15 GB | Số byte được báo cáo cùng run; GB thập phân; không đồng nhất với dung lượng file Parquet |
| `ch4-memory-last-sample.tex` | RAM container ở mẫu cuối so với giới hạn | Số liệu được báo cáo cùng run; không phải đỉnh sử dụng RAM |

## Số liệu ba biểu đồ chương 4

| Query | P50 (ms) | P95 (ms) |
|---|---:|---:|
| Q1 / Bronze | 344 | 422 |
| Q2a / Silver | 1.305 | 1.465 |
| Q2b / Quarantine | 537 | 694 |
| Q3 / PostgreSQL | 1.457 | 1.651 |

Payload được báo cáo tại ba ranh giới source, Bridge delivery và Bronze đều là **16.226.141.856 byte**, tương đương **16,226141856 GB** với 1 GB = 10^9 byte. Ba số tổng bằng nhau là đối soát tổng lượng payload; tự nó không chứng minh mọi `event_id` đều duy nhất và không bị thiếu. Mục tiêu 30 GB/4 giờ chưa chạy, nên không vẽ thành kết quả đo.

Mẫu RAM cuối: Spark **1,752 GiB / 2,5 GiB = 70,08%**; PostgreSQL **401,5 MiB / 512 MiB ≈ 78,42%**. Đây không phải chuỗi thời gian hay giá trị peak.

## Tài liệu kiểm chứng

- [Chương 4 tại commit nguồn](https://github.com/lucas-traumen/Bigdata/blob/6343a180f84c46b611fbef73db1e394fb201abe3/Documents/report/chapters/04-results.tex): nguồn trực tiếp của tổng payload, P50/P95 và mẫu RAM cuối dùng trong ba biểu đồ. Đây là số đo được tác giả repository báo cáo, chưa được lần biên tập này kiểm lại từ raw log.
- [EVALUATION.md tại commit nguồn](https://github.com/lucas-traumen/Bigdata/blob/6343a180f84c46b611fbef73db1e394fb201abe3/implementation/docs/EVALUATION.md): phương pháp, checklist và trạng thái đánh giá. File này không chứa đầy đủ số liệu chi tiết của ba biểu đồ.
- [TEST_REPORT.md tại commit nguồn](https://github.com/lucas-traumen/Bigdata/blob/6343a180f84c46b611fbef73db1e394fb201abe3/implementation/docs/TEST_REPORT.md): kiểm thử chức năng, fixture dữ liệu lỗi, restart và Gold rerun. Các phép này thuộc đợt kiểm thử riêng.
- [Nguồn runtime tại commit nguồn](https://github.com/lucas-traumen/Bigdata/tree/6343a180f84c46b611fbef73db1e394fb201abe3/implementation): cơ sở đối chiếu mô tả triển khai.

Ba file trong `evidence/` là bản chụp nguyên trạng của hai tài liệu đánh giá và chương 4 cũ. Chúng phục vụ đối chiếu nguồn, không thuộc phần nội dung đã sửa và không được include trong bản PDF mới.

Log thô của phép tải nằm ngoài repository. Lần biên tập này đối chiếu với mã nguồn và tài liệu trên, không chạy lại benchmark và không bổ sung số đo mới. Các kế hoạch kiểm chứng H1–H4, sweep cấu hình, recovery định lượng và mục tiêu tải tiếp theo vẫn được ghi rõ là công việc chưa thực hiện.
